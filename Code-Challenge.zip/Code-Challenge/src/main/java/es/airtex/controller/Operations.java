package es.airtex.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import org.springframework.stereotype.Repository;
import es.airtex.model.Product;

@Repository
public class Operations {

	protected static final Map<String, Product> mapProducts = new HashMap<String, Product>();
	
	
	static {
		initializeProducts();
	}
	
	
	protected static void initializeProducts() {
		
		// Products used as test examples were provided on the challenge.
		
		Product prod1 = new Product("M20324", (float) 8.5, 350); 
		Product prod2 = new Product("AC7836", (float) 7,   245); 
		Product prod3 = new Product("C77154", (float) 9.5,  34); 
		Product prod4 = new Product("BB5476", (float) 6.5, 650); 
		Product prod5 = new Product("B42000", (float) 10, 1350); 

 
		mapProducts.put(prod1.getProductID(), prod1);
		mapProducts.put(prod2.getProductID(), prod2);
		mapProducts.put(prod3.getProductID(), prod3);
		mapProducts.put(prod4.getProductID(), prod4);
		mapProducts.put(prod5.getProductID(), prod5);
		
	}
	
	public Product getProduct(String productID) {
        return mapProducts.get(productID);
    }
	
	public void updateOrAddProduct(Product prod) {
		mapProducts.put(prod.getProductID(), prod);
	}
 
    public void deleteProduct(String productID) {
    	mapProducts.remove(productID);
    }
    
    public ArrayList<Product> getAllProducts() {
    	ArrayList<Product> arrList = new ArrayList<Product>();
    	arrList.addAll(mapProducts.values());
    	
    	return arrList;
    }

	
}
