package es.airtex.controller;

import java.util.ArrayList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import es.airtex.model.Product;


@RestController
@RequestMapping("/")
public class RestAPI {
	
	@Autowired
	private Operations operations;

	
	@GetMapping("review/{product_id}")
	@ResponseBody
    public Product getProduct(@PathVariable("product_id") String product_id) {
		
		/*
		 * READ part of the CRUD operation. Given any product id, we get its data.
		 */
		
        return operations.getProduct(product_id);
    }
	
	@GetMapping("review/all")
	@ResponseBody
    public ArrayList<Product> getAllProducts() {
		
		/*
		 * READ part of the CRUD operation. Extra. Return all products with associated data.
		 * 		Handle with caution with large amounts for products.
		 */
		
        return operations.getAllProducts();
    }
	
	
	@SuppressWarnings("static-access")
	@PostMapping("review")
	@ResponseBody
	public String createProduct(@RequestBody Product prod) {
		
		/*
		 * CREATE part of the CRUD operation. Returns confirmation if product does not exist.
		 * 		
		 * 		Due to the need for extra information, besides the id, the creation of new
		 * 		products is NOT done through a POST to /review/{product_id}, as done in the GET.
		 * 		Of course, it could be done if required, but extra info still need to be sent.
		 * 		It could be argued to be more secure placing the id on the URL as well, to perform
		 * 		a check.
		 */
		
		String result; 
		
		if( operations.mapProducts.containsKey(prod.getProductID()) ) {
			result = "Product with ID " + prod.getProductID() + " already exists. Use proper method to UPDATE";
		}
		else {
			operations.updateOrAddProduct(prod);
			result = "Done! Product with ID " + prod.getProductID() + " created."; 
		}
		
		
		return result;
	}
	
	@PutMapping("review")
	@ResponseBody
	public String updateProduct(@RequestBody Product prod) {
		
		/*
		 * UPDATE part of the CRUD operation. If product does not exist, it is created. If it 
		 * 		does, it is updated. Same logic as for the createProduct method.
		 */
		
		operations.updateOrAddProduct(prod);
		
		return "Done! Product with ID " + prod.getProductID() + " updated."; 
	}
	
	
	@DeleteMapping("review/{product_id}")
	@ResponseBody
	public String deleteProduct( @PathVariable("product_id") String product_id ) {
		
		/*
		 * DELETE part of the CRUD operation. Given any product id, it gets deleted.
		 */
		
		operations.deleteProduct(product_id);
		
		return "Done! Product with ID " + product_id + " deleted.";
		
	}
	
	
	
	
	
}
