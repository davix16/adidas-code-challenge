package es.airtex.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import es.airtex.auth.AuthenticationEntryPoint;

@Configuration
@EnableWebSecurity
public class SecurityConfig extends WebSecurityConfigurerAdapter {

	@Autowired
    private AuthenticationEntryPoint authEntryPoint;
	
	@Bean
    public BCryptPasswordEncoder passwordEncoder() {
        BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
        return encoder;
    }
	
	@Override
	protected void configure(HttpSecurity http) throws Exception {
		
		http.authorizeRequests()
        	.antMatchers(HttpMethod.GET, "/review/{product_id}", "/review/all").permitAll()
        	.anyRequest().authenticated()
        	.and()
        	.httpBasic()
			.authenticationEntryPoint(authEntryPoint);
		
	}
	
	@Autowired
	public void configureGlobal(AuthenticationManagerBuilder auth) throws Exception {
		
		String pass = this.passwordEncoder().encode("adidas");
		
		System.out.println("\n\n" + pass + "\n\n");
		
		auth
			.inMemoryAuthentication()
				.withUser("adidas").password(pass).roles("USER", "ADMIN");
	}
}
