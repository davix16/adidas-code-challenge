package es.airtex.model;

public class Product {
	
	String productID; 
	float reviewScore;
	long numberReviews;
	
	
	
	public Product() {}
	
	public Product(String productID, float reviewScore, long numberReviews) {
		this.productID = productID;
		this.reviewScore = reviewScore;
		this.numberReviews = numberReviews;
	}
	
	public String getProductID() {
		return productID;
	}
	public void setProductID(String productID) {
		this.productID = productID;
	}
	public float getReviewScore() {
		return reviewScore;
	}
	public void setReviewScore(float reviewScore) {
		this.reviewScore = reviewScore;
	}
	public long getNumberReviews() {
		return numberReviews;
	}
	public void setNumberReviews(long numberReviews) {
		this.numberReviews = numberReviews;
	}

}
