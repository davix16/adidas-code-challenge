package es.airtex.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Repository;
import org.springframework.web.client.RestTemplate;

import es.airtex.model.Product;
import es.airtex.model.Review;

@Repository
public class Operations {

	
	public Product getProduct(String productID) {
		
		/*
		 * First, Adidas API part.
		 */
		String uri_adidas = "https://www.adidas.co.uk/api/products/{id}";
	     
	    Map<String, String> params_adidas = new HashMap<String, String>();
	    params_adidas.put("id", productID);
	     
	    RestTemplate restTemplate_adidas = new RestTemplate();
	    Product result = restTemplate_adidas.getForObject(uri_adidas, Product.class, params_adidas);
	    
	    
	    /*
	     * Second, our previously created API
	     */
	    String uri_own = "http://localhost:8081/review/{id}";
	     
	    Map<String, String> params_own = new HashMap<String, String>();
	    params_own.put("id", productID);
	     
	    RestTemplate restTemplate_own = new RestTemplate();
	    Review review = restTemplate_own.getForObject(uri_own, Review.class, params_own);
	    
	    result.setReview(review);
	    
	    
	    
	    return result;
	}
}
