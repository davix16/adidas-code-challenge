package es.airtex.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import es.airtex.model.Product;

@RestController
@RequestMapping("/")
public class RestAPI {
	
	@Autowired
	private Operations operations;
	
	
	@GetMapping("product/{product_id}")
	@ResponseBody
    public Product getProduct(@PathVariable("product_id") String product_id) {
		
        return operations.getProduct(product_id);
    }

}
