package es.airtex.model;

public class Breadcrumb_List_Item {
	
	String text;
	String link;
	
	public Breadcrumb_List_Item() {}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public String getLink() {
		return link;
	}

	public void setLink(String link) {
		this.link = link;
	}
	
	

}
