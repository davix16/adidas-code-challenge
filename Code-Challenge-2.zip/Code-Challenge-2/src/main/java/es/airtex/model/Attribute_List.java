package es.airtex.model;

public class Attribute_List {

	boolean isWaitingRoomProduct;
	String brand;
	String[] collection;
	String category;
	String color;
	String gender;
	String gender_sub;
	boolean personalizable;
	boolean mandatory_personalization;
	boolean customizable;
	On_Model_Measurement on_model_measurement;
	String pricebook;
	boolean sale;
	boolean outlet;
	String[] sport;
	String size_chart_link;
	String preview_to;
	boolean coming_soon_signup;
	String hashtag;
	String[] productType;
	String[] sportSub;
	String search_color;
	
	public Attribute_List() {}

	public boolean isWaitingRoomProduct() {
		return isWaitingRoomProduct;
	}

	public void setWaitingRoomProduct(boolean isWaitingRoomProduct) {
		this.isWaitingRoomProduct = isWaitingRoomProduct;
	}

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	public String[] getCollection() {
		return collection;
	}

	public void setCollection(String[] collection) {
		this.collection = collection;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getGender_sub() {
		return gender_sub;
	}

	public void setGender_sub(String gender_sub) {
		this.gender_sub = gender_sub;
	}

	public boolean isPersonalizable() {
		return personalizable;
	}

	public void setPersonalizable(boolean personalizable) {
		this.personalizable = personalizable;
	}

	public boolean isMandatory_personalization() {
		return mandatory_personalization;
	}

	public void setMandatory_personalization(boolean mandatory_personalization) {
		this.mandatory_personalization = mandatory_personalization;
	}

	public boolean isCustomizable() {
		return customizable;
	}

	public void setCustomizable(boolean customizable) {
		this.customizable = customizable;
	}

	public On_Model_Measurement getOn_model_measurement() {
		return on_model_measurement;
	}

	public void setOn_model_measurement(On_Model_Measurement on_model_measurement) {
		this.on_model_measurement = on_model_measurement;
	}

	public String getPricebook() {
		return pricebook;
	}

	public void setPricebook(String pricebook) {
		this.pricebook = pricebook;
	}

	public boolean isSale() {
		return sale;
	}

	public void setSale(boolean sale) {
		this.sale = sale;
	}

	public boolean isOutlet() {
		return outlet;
	}

	public void setOutlet(boolean outlet) {
		this.outlet = outlet;
	}

	public String[] getSport() {
		return sport;
	}

	public void setSport(String[] sport) {
		this.sport = sport;
	}

	public String getSize_chart_link() {
		return size_chart_link;
	}

	public void setSize_chart_link(String size_chart_link) {
		this.size_chart_link = size_chart_link;
	}

	public String getPreview_to() {
		return preview_to;
	}

	public void setPreview_to(String preview_to) {
		this.preview_to = preview_to;
	}

	public boolean isComing_soon_signup() {
		return coming_soon_signup;
	}

	public void setComing_soon_signup(boolean coming_soon_signup) {
		this.coming_soon_signup = coming_soon_signup;
	}

	public String getHashtag() {
		return hashtag;
	}

	public void setHashtag(String hashtag) {
		this.hashtag = hashtag;
	}

	public String[] getProductType() {
		return productType;
	}

	public void setProductType(String[] productType) {
		this.productType = productType;
	}

	public String[] getSportSub() {
		return sportSub;
	}

	public void setSportSub(String[] sportSub) {
		this.sportSub = sportSub;
	}

	public String getSearch_color() {
		return search_color;
	}

	public void setSearch_color(String search_color) {
		this.search_color = search_color;
	}
	
	
	
}
