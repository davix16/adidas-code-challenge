package es.airtex.model;

public class Product_Highlights {

	String image_reference;
	String headline;
	String copy;
	
	public Product_Highlights() {}

	public String getImage_reference() {
		return image_reference;
	}

	public void setImage_reference(String image_reference) {
		this.image_reference = image_reference;
	}

	public String getHeadline() {
		return headline;
	}

	public void setHeadline(String headline) {
		this.headline = headline;
	}

	public String getCopy() {
		return copy;
	}

	public void setCopy(String copy) {
		this.copy = copy;
	}
	
	
}
