package es.airtex.model;

public class Review {

	String productID;
	float reviewScore;
	long numberReviews;
	
	public Review() {}

	public String getProductID() {
		return productID;
	}

	public void setProductID(String productID) {
		this.productID = productID;
	}

	public float getReviewScore() {
		return reviewScore;
	}

	public void setReviewScore(float reviewScore) {
		this.reviewScore = reviewScore;
	}

	public long getNumberReviews() {
		return numberReviews;
	}

	public void setNumberReviews(long numberReviews) {
		this.numberReviews = numberReviews;
	}
	
	
	
	
}
