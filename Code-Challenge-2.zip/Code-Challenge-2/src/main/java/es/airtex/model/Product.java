package es.airtex.model;

import java.util.ArrayList;

public class Product {

	String id;
	String name;
	String model_number;
	String product_type;
	Metadata meta_data;
	ArrayList<View_List_Item> view_list;
	Pricing_Information pricing_information;
	Attribute_List attribute_list;
	Callouts callouts;
	Product_Description product_description;
	ArrayList<Breadcrumb_List_Item> breadcrumb_list;
	ArrayList<Product_Cards_Item> product_cards;
	ArrayList<Product_Link_List_Item> product_link_list;
	Review review;
	
	public Product() {}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getModel_number() {
		return model_number;
	}

	public void setModel_number(String model_number) {
		this.model_number = model_number;
	}

	public String getProduct_type() {
		return product_type;
	}

	public void setProduct_type(String product_type) {
		this.product_type = product_type;
	}

	public Metadata getMeta_data() {
		return meta_data;
	}

	public void setMeta_data(Metadata meta_data) {
		this.meta_data = meta_data;
	}

	public ArrayList<View_List_Item> getView_list() {
		return view_list;
	}

	public void setView_list(ArrayList<View_List_Item> view_list) {
		this.view_list = view_list;
	}

	

	public Attribute_List getAttribute_list() {
		return attribute_list;
	}

	public void setAttribute_list(Attribute_List attribute_list) {
		this.attribute_list = attribute_list;
	}

	public Callouts getCallouts() {
		return callouts;
	}

	public void setCallouts(Callouts callouts) {
		this.callouts = callouts;
	}

	public Product_Description getProduct_description() {
		return product_description;
	}

	public void setProduct_description(Product_Description product_description) {
		this.product_description = product_description;
	}

	public ArrayList<Breadcrumb_List_Item> getBreadcrumb_list() {
		return breadcrumb_list;
	}

	public void setBreadcrumb_list(ArrayList<Breadcrumb_List_Item> breadcrumb_list) {
		this.breadcrumb_list = breadcrumb_list;
	}

	public ArrayList<Product_Link_List_Item> getProduct_link_list() {
		return product_link_list;
	}

	public void setProduct_link_list(ArrayList<Product_Link_List_Item> product_link_list) {
		this.product_link_list = product_link_list;
	}

	

	public ArrayList<Product_Cards_Item> getProduct_cards() {
		return product_cards;
	}

	public void setProduct_cards(ArrayList<Product_Cards_Item> product_cards) {
		this.product_cards = product_cards;
	}

	public Pricing_Information getPricing_information() {
		return pricing_information;
	}

	public void setPricing_information(Pricing_Information pricing_information) {
		this.pricing_information = pricing_information;
	}

	public Review getReview() {
		return review;
	}

	public void setReview(Review review) {
		this.review = review;
	}
	
	
	
}
