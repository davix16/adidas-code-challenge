package es.airtex.model;

public class Description_Assets {

	public Description_Assets() {}
}
