package es.airtex.model;

public class Product_Cards_Item {
	
	String id;
	String value;
	
	public Product_Cards_Item() {}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}
	
	

}
