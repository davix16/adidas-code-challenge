package es.airtex.model;

import java.util.ArrayList;

public class Product_Description {

	String title;
	String subtitle;
	String text;
	String[] usps;
	ArrayList<Product_Highlights> product_highlights;
	Description_Assets description_assets;
	
	public Product_Description() {}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getSubtitle() {
		return subtitle;
	}

	public void setSubtitle(String subtitle) {
		this.subtitle = subtitle;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public String[] getUsps() {
		return usps;
	}

	public void setUsps(String[] usps) {
		this.usps = usps;
	}

	public ArrayList<Product_Highlights> getProduct_highlights() {
		return product_highlights;
	}

	public void setProduct_highlights(ArrayList<Product_Highlights> product_highlights) {
		this.product_highlights = product_highlights;
	}

	public Description_Assets getDescription_assets() {
		return description_assets;
	}

	public void setDescription_assets(Description_Assets description_assets) {
		this.description_assets = description_assets;
	}
	
	
	
}
