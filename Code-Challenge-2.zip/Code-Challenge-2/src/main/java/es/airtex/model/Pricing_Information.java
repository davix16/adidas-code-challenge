package es.airtex.model;

public class Pricing_Information {
	
	float standard_price;
	float standard_price_no_vat;
	float currentPrice;
	
	public Pricing_Information() {}

	public float getStandard_price() {
		return standard_price;
	}

	public void setStandard_price(float standard_price) {
		this.standard_price = standard_price;
	}

	public float getStandard_price_no_vat() {
		return standard_price_no_vat;
	}

	public void setStandard_price_no_vat(float standard_price_no_vat) {
		this.standard_price_no_vat = standard_price_no_vat;
	}

	public float getCurrentPrice() {
		return currentPrice;
	}

	public void setCurrentPrice(float currentPrice) {
		this.currentPrice = currentPrice;
	}
	
	

}
