package es.airtex.model;

public class Product_Link_List_Item {
	
	String type;
	String name;
	String url;
	String image;
	String altImage;
	Pricing_Information_Reduced pricing_information;
	String default_color;
	String search_color;
	String source;
	String badge_text;
	String badge_style;
	
	public Product_Link_List_Item() {}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	public String getAltImage() {
		return altImage;
	}

	public void setAltImage(String altImage) {
		this.altImage = altImage;
	}

	public String getDefault_color() {
		return default_color;
	}

	public void setDefault_color(String default_color) {
		this.default_color = default_color;
	}

	public String getSearch_color() {
		return search_color;
	}

	public void setSearch_color(String search_color) {
		this.search_color = search_color;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getBadge_text() {
		return badge_text;
	}

	public void setBadge_text(String badge_text) {
		this.badge_text = badge_text;
	}

	public String getBadge_style() {
		return badge_style;
	}

	public void setBadge_style(String badge_style) {
		this.badge_style = badge_style;
	}

	public Pricing_Information_Reduced getPricing_information() {
		return pricing_information;
	}

	public void setPricing_information(Pricing_Information_Reduced pricing_information) {
		this.pricing_information = pricing_information;
	}
	
	

}
