package es.airtex.model;

public class Metadata {

	String page_title;
	String site_name;
	String description;
	String keywords;
	String canonical;
	
	
	public Metadata() {}


	public String getPage_title() {
		return page_title;
	}


	public void setPage_title(String page_title) {
		this.page_title = page_title;
	}


	public String getSite_name() {
		return site_name;
	}


	public void setSite_name(String site_name) {
		this.site_name = site_name;
	}


	public String getDescription() {
		return description;
	}


	public void setDescription(String description) {
		this.description = description;
	}


	public String getKeywords() {
		return keywords;
	}


	public void setKeywords(String keywords) {
		this.keywords = keywords;
	}


	public String getCanonical() {
		return canonical;
	}


	public void setCanonical(String canonical) {
		this.canonical = canonical;
	}
	
	
	
}
