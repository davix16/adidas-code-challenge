package es.airtex.model;

public class On_Model_Measurement {

	String chest;
	String model_height;
	String product_size;
	String waist;
	
	public On_Model_Measurement() {}

	public String getChest() {
		return chest;
	}

	public void setChest(String chest) {
		this.chest = chest;
	}

	public String getModel_height() {
		return model_height;
	}

	public void setModel_height(String model_height) {
		this.model_height = model_height;
	}

	public String getProduct_size() {
		return product_size;
	}

	public void setProduct_size(String product_size) {
		this.product_size = product_size;
	}

	public String getWaist() {
		return waist;
	}

	public void setWaist(String waist) {
		this.waist = waist;
	}
	
	
}
