package es.airtex.model;

public class Callouts_Bottom_Stack {

	String title;
	String body;
	String link_text;
	
	public Callouts_Bottom_Stack() {}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getBody() {
		return body;
	}

	public void setBody(String body) {
		this.body = body;
	}

	public String getLink_text() {
		return link_text;
	}

	public void setLink_text(String link_text) {
		this.link_text = link_text;
	}
	
	
}
