package es.airtex.model;

public class Callouts {

	Callouts_Bottom_Stack callout_bottom_stack;
	
	public Callouts() {}

	public Callouts_Bottom_Stack getCallout_bottom_stack() {
		return callout_bottom_stack;
	}

	public void setCallout_bottom_stack(Callouts_Bottom_Stack callout_bottom_stack) {
		this.callout_bottom_stack = callout_bottom_stack;
	}
	
	
}
