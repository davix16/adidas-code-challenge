package es.airtex.model;

public class Pricing_Information_Reduced {

	float standard_price;
	
	public Pricing_Information_Reduced() {}

	public float getStandard_price() {
		return standard_price;
	}

	public void setStandard_price(float standard_price) {
		this.standard_price = standard_price;
	}
	
	
}
